
/**
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
**/

#include <stdbool.h>
#include "dictionary.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define LENGHTWORD 45
#define HASHLENGHT 150000


short strcomp(const char* str1, const char* str2);
unsigned int get_hash(const char * word);

//struct of linked list for solution collisions on hash table
struct hash_table{
    char word[LENGHTWORD + 1];
    struct hash_table *next;
    //добавить поле флага, имеется ли слово?!
}*hash_dict[HASHLENGHT];                             ///сделать через указатели?!

//lenght dictionary
unsigned int dict_len = 0;



/**
 * Loads dictionary into memory.  Returns true if successful else false.
**/
bool load(const char* dictionary)
{
    //open dictionary file and check on error
    FILE * dict = fopen(dictionary, "r");
    if(dict == NULL){
        printf("File %s not found.\n", dictionary);
        return false;
    }

    struct hash_table *curnode, node;
    dict_len = 0;
    int hash = 0;
    char str[LENGHTWORD];

    //TODO:
    while( fgets(str, LENGHTWORD, dict) != NULL ){
        //TODO:
        if(str[strlen(str) - 1 == '\n']){//end word in dictionary ends on '\0', oter words eds on '\n'.
                                        //when do not clear symbol word, last word, check on they error
            (str[strlen(str) - 1] = 0);
        }
        hash = get_hash(str);
        dict_len++;
        if(dict_len == 143091 || dict_len == 143092 || dict_len == 1){
            printf("add %d word. is it - %s", dict_len, str);
            getchar();
        }

        if(hash_dict[hash] == NULL){
            hash_dict[hash] = malloc(sizeof(node));
            strcpy(hash_dict[hash]->word, str);
        }
        else{
            curnode = hash_dict[hash];
            while(curnode->next != NULL){
                curnode = curnode->next;
            }
            curnode->next = malloc(sizeof(node));
            curnode = curnode->next;
            strcpy(curnode->word, str);
        }
    }
/**
 ***************************************************************************

    for(int i = 0; i < HASHLENGHT; i++){
        if(hash_dict[i] != NULL){
            curnode = hash_dict[i];
            printf("\nlinked list %d:\n", i);
            printf(" ||hash = %d|---|%s",get_hash(curnode->word), curnode->word);
            while(curnode->next != NULL){
                curnode = curnode->next;
                printf(" ||hash = %d|---|%s",get_hash(curnode->word), curnode->word);
            }
            printf("||||||||||||||||||||||||||||||||||||\n");
            //getchar();
        }
    }

 ***************************************************************************
**/

    if (fclose(dict) == EOF){
        unload();
        return false;
    }

    return true;
}



/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    return dict_len;
}



/**
 * Unloads dictionary from memory.  Returns true if successful else false.
**/
bool unload(void)//КУЛИ ТУТ ВОЗВРАЩАТЬ?! так и не одуплил что тут может пойти не так что бы вернуть false
{
    struct hash_table *ptr;
    struct hash_table *cur_node;
    //walk on the all hash table
    for(int i = 0; i < HASHLENGHT; i++){
        ptr = hash_dict[i];
        //whenewer there is collision(creates linked list) - clear from memory this data list
        while(ptr != NULL){
            cur_node = ptr->next;
            free(ptr);
            ptr = cur_node;
        }
    }
    return true;
}

/**
 * Returns true if word is in dictionary else false.
**/
bool check(const char* word)
{
    //TODO:
    char str[LENGHTWORD] = {};
    int i;
    for(i = 0; i < strlen(word); i++){
        str[i] = tolower(word[i]);
    }
    int hash = get_hash(str);

    //в ходе экскеремента мы убедились что словарь загружается без \n
    //hash str считается тоже без \n
    //значит - что то не так с реализацией сравнения строк?!
    //printf("hash str - %s = %d\n", str, hash);
    //printf("hash hash_dict[hash] - %s = %d\n", hash_dict[hash].word, hash);



    struct hash_table *ptr = hash_dict[hash];
    if(ptr != NULL){
        while(ptr != NULL){
            if(strcmp(str, ptr->word) == 0)
                return true;
            else
                ptr = ptr->next;
        }
    }
    //printf("\nword = %s\nstr = %s\nhash_dict[%d] = %s\nINPUT COMMAND:\n", word, str, hash, ptr->word);
    //printf("strcmp(str, ptr->word) = strcmp(%s,%s) =  %s = %d\n",
    //                                    str, ptr->word, str, (ptr == NULL) ? 0 : strcmp(str, ptr->word));
    //getchar();
    return false;
}


/**
 * strcomp - compare 2 sring
 * if string are equal, then return 0.
 * else return 1 if str1 > str2 and and vice versa
 * return 2 if str1 or str2 overflow specified length
**/

//compare two string, when end to '\0'
short strcomp(const char* str1, const char* str2){

    char c1, c2;
    short i = 0;
    do{
        c1 = tolower(str1[i]);
        c2 = tolower(str2[i]);
        i++;
    }while(c1 == c2 && (c1 != '\0' || c2 !='\0'));

	return c1 - c2;
}
//count hash for string key
unsigned int get_hash(const char * word){

    unsigned int hash = 0;
    for(int i = 1; i <= strlen(word); i++){
        hash += word[i-1] * i;                      //если еще ввести независимый коэффициент k. C каждой след буквой, умножающий hash*k??
    }
    return hash % HASHLENGHT;
}
