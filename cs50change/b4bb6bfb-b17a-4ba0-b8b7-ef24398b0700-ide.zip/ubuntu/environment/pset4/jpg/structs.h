
typedef uint32_t DWORD;
typedef int32_t  LONG;
typedef uint16_t WORD;
