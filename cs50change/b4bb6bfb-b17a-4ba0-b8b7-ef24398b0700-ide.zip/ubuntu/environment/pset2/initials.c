#include <stdio.h>
#include <cs50.h>
#include <string.h>

#define LENNAME 50
string initial(string name, int len);
void initial2(char *name);

int main(){
    string name = get_string("Write your name\n");
    name = initial(name, strlen(name));
    printf("%s\n",  name);

	char name2[LENNAME] = {'\0'};
    char c;
    int i = 0;

    while (((c = getchar()) != EOF) && (c != '\n') && i < 50) name2[i++] = c;

    initial2(name2);
    printf("%s\n",name2);
}

string initial(string name, int len){

	int i, n, inWord;
	i = n = inWord = 0;

	while (i < len) {

		if (name[i] == ' ') inWord = 0;
		else if (inWord == 1 || inWord == 2 ) inWord = 2;
		else inWord = 1;

		if (inWord == 1) {
			if ((name[i] >= 'a') && (name[i] <= 'z'))
				name[i] = name[i] - ('a' - 'A');
			name[n++] = name[i];
		}
	i++;
	}
	name[i] = '\0';
	for (i = n; i < len; i++) name[i] = '\0';
    return name;
}

void initial2(char *name) {

	int i, n, inWord;
	i = n = inWord = 0;

	while (name[i] != '\n' && name[i] != EOF && name[i] != '\0') {

		if (name[i] == ' ') inWord = 0;
		else if (inWord == 1 || inWord == 2 ) inWord = 2;
		else inWord = 1;

		if (inWord == 1) {
			if ((name[i] >= 'a') && (name[i] <= 'z'))
				name[i] = name[i] - ('a' - 'A');
			name[n++] = name[i];
		}
		i++;
	}
	name[i] = '\0';
	for (i = n; name[i] != '\0'; i++) name[i] = '\0';
}
