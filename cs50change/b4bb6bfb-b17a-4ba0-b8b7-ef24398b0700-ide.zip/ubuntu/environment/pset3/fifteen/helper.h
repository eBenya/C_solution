


//coord tile
struct Tile{
    unsigned short y; //column
    unsigned short x; //row
};

void swap(int *a, int *b);